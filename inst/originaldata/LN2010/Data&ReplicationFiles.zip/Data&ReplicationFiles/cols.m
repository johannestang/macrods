function col=cols(x);
[row,col]=size(x);
