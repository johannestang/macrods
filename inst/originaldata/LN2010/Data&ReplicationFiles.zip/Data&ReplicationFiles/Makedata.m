load lndata
series=[];
rawdata=[];
tcode=[];
thr=6;
N=cols(macrodat);
dates=(59+1/12:1/12:108)';
data=trimr(macrodat,12,0);
dates=trimr(dates,12,0);
for i=1:N;
  dum=data(:,i);
  m=mean(dum);
  if isnan(m) ==0;
      rawdata=[rawdata dum];
  series=str2mat(series,headertext{1,i});
  tcode=[tcode; vartype(i)];
  else;
    disp([i m]);
  end;
end; 
series=trimr(series,1,0);
y=[];
N=cols(rawdata);
for i=1:N;
  if tcode(i)==0; tcode(i)=1; end; 
dum=transx(rawdata(:,i),tcode(i));
y=[y dum];
end;
y=y(49:end,:); % Data 1964.1 - 2007.12

[ehat_T,Fhat_T,lamhat_T,ve2_T]=pc_T(standard(y),8);