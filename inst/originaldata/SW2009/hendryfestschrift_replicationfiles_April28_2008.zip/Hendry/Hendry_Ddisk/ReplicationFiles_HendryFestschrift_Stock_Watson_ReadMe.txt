This document describes the replication files for

"Forecasting In Dynamic Factor Models Subject to Strutural Instability"

By James H. Stock and Mark W. Watson

April 2008 revision

(This paper was written for a Festsrchrift honoring David Hendry).

All Calculations are carried out using GAUSS. Programs are in directory "GSS"


1. Data

Data in in \data\hendry_data.xls

2. Results

Table 1: Results computed in nofactors_1.gss
Table 2: Results computed in Stability_CanCor.gss
Table 3: Results computed in Split_Sample_Calculations.gss
Table 4: Results computed in Split_Sample_Calculations.gss 
Table 5: Results computed in Split_Sample_Calculations.gss
Data Appendix Table: Table produced in data_appendix_1.gss

Figure 1: Results Computed in Figure 1.gss
Figure 2: Results Computed in Figure 2.gss
Figure 3: Results Computed in Figure 3.gss
Figure 4: Results Computed in Figure 4.gss