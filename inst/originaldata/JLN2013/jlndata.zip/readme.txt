This .zip file contains 6 Microsoft Excel documents with data and estimates 
from: Jurado, Ludvigson, and Ng (2013) "Measuring Uncertainty."
See the paper and its data appendix for more information on these series.

(1) macro_raw_data.xlsx           : raw macroeconomic and financial data
(2) macro_forecasting_factors.xlsx: macroeconomic factors for forecasting
(3) macro_uncertainty.xlsx        : aggregate macroeconomic uncertainty at various horizons
(4) firm_raw_data.xlsx            : raw firm-level profit growth data
(5) firm_forecasting_factors.xlsx : firm-level factors for forecasting
(6) firm_uncertainty.xlsx         : aggregate firm-level uncertainty at various horizons
