README.TXT
===========================================================================
DESCRIPTION:
This zip file contains a 2015:01 vintage dataset (csv file) and MATLAB
code that loads in the data, transforms it, removes outliers from the 
transformed data, and saves it as a MAT-file to be used for factor 
construction.

===========================================================================
LIST OF FILES:

generate_freddata.m     

    This is the main MATLAB script. It performs all the tasks mentioned 
    above using auxiliary functions that are described below. It produces 
    the MAT-file freddata.mat.

---------------------------------------------------------------------------

FRED-MD_2015m1.csv               

    Raw data that is read into generate_freddata.m.

---------------------------------------------------------------------------

prepare_missing.m           

    MATLAB function that transforms the raw data into stationary form. 
    Used in generate_freddata.m.

---------------------------------------------------------------------------

remove_ouliers.m            

    MATLAB function that removes outliers from the data. A data point x is 
    considered an outlier if |x-median|>10*interquartile_range. Used in 
    generate_freddata.m.

---------------------------------------------------------------------------

freddata.mat              

    This is the final output file from generate_freddata.m. It contains
    the following variables:

        1) data  = dataset after all series have been trasnformed and all
                   ouliers removed. Each column contains one time series. 
                   Observations are monthly

        2) dates = column vector containing dates corresponding to the 
                   time series in "data"

        3) names = cell array containing the name of each series in "data"

        4) tcode = row vector containing transformation code corresponding
                   to each time series in "data"

===========================================================================
